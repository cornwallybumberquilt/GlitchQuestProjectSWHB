﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Inventory
{
    internal abstract class Equipment : Item
    {
        public Equipment(string name) : base(name) { }

        public void Equip() { }
    }
}
