﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Inventory
{
    internal class Inventory
    {
        List<Item> items;

        public Inventory()
        {
            items = new List<Item>();
        }

        public void Add(Item item)
        {
            throw new NotImplementedException();
        }
        public void Remove(Item item)
        {
            throw new NotImplementedException();
        }
    }
}
