﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Enemies
{
    internal class Snake : Enemy
    {
        public Snake(int size) : base(size)
        {
            _attack = 1;
            _defense = 1;
        }
    }
}
