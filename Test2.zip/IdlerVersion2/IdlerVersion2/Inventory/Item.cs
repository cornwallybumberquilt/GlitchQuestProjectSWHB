﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Inventory
{
    public class Item
    {
        public string _name;
        public int _points;

        public Item(string name, int points)
        {
            _name = name;
            _points = points;

        }

        public void ItemEffect() { }


    }

}
