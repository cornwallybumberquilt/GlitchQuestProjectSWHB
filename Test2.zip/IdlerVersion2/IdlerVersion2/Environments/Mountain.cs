﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a mountain environment object
    /// </summary>
    internal class Mountain : Environment
    {
        public Mountain(int size) : base(size) { }

        public void HandleCollision() { }
    }
}
