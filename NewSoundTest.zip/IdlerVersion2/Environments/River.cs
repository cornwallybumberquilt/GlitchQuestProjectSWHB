﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a river environment object
    /// </summary>
    internal class River : Environment
    {
        public River(int size) : base(size) { }

        public void HandleCollision() { }
    }
}
