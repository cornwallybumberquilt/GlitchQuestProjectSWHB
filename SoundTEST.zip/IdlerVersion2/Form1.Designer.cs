﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            trackBar1 = new TrackBar();
            InventoryPlaceholder = new ListBox();
            menuStrip1 = new MenuStrip();
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            loadToolStripMenuItem = new ToolStripMenuItem();
            aboutToolStripMenuItem = new ToolStripMenuItem();
            SpeedSliderText = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox4 = new PictureBox();
            listBox1 = new ListBox();
            GridDisplay = new Panel();
            pictureBox65 = new PictureBox();
            pictureBox66 = new PictureBox();
            pictureBox67 = new PictureBox();
            pictureBox68 = new PictureBox();
            pictureBox69 = new PictureBox();
            pictureBox70 = new PictureBox();
            pictureBox71 = new PictureBox();
            pictureBox72 = new PictureBox();
            pictureBox73 = new PictureBox();
            pictureBox74 = new PictureBox();
            pictureBox59 = new PictureBox();
            pictureBox60 = new PictureBox();
            pictureBox61 = new PictureBox();
            pictureBox62 = new PictureBox();
            pictureBox63 = new PictureBox();
            pictureBox64 = new PictureBox();
            pictureBox50 = new PictureBox();
            pictureBox51 = new PictureBox();
            pictureBox52 = new PictureBox();
            pictureBox53 = new PictureBox();
            pictureBox54 = new PictureBox();
            pictureBox55 = new PictureBox();
            pictureBox56 = new PictureBox();
            pictureBox57 = new PictureBox();
            pictureBox58 = new PictureBox();
            pictureBox41 = new PictureBox();
            pictureBox42 = new PictureBox();
            pictureBox43 = new PictureBox();
            pictureBox44 = new PictureBox();
            pictureBox45 = new PictureBox();
            pictureBox46 = new PictureBox();
            pictureBox47 = new PictureBox();
            pictureBox48 = new PictureBox();
            pictureBox49 = new PictureBox();
            pictureBox32 = new PictureBox();
            pictureBox33 = new PictureBox();
            pictureBox34 = new PictureBox();
            pictureBox35 = new PictureBox();
            pictureBox36 = new PictureBox();
            pictureBox37 = new PictureBox();
            pictureBox38 = new PictureBox();
            pictureBox39 = new PictureBox();
            pictureBox40 = new PictureBox();
            pictureBox23 = new PictureBox();
            pictureBox24 = new PictureBox();
            pictureBox25 = new PictureBox();
            pictureBox26 = new PictureBox();
            pictureBox27 = new PictureBox();
            pictureBox28 = new PictureBox();
            pictureBox29 = new PictureBox();
            pictureBox30 = new PictureBox();
            pictureBox31 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            pictureBox20 = new PictureBox();
            pictureBox21 = new PictureBox();
            pictureBox22 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            listBox2 = new ListBox();
            ((System.ComponentModel.ISupportInitialize)trackBar1).BeginInit();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)SpeedSliderText).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            GridDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox65).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // trackBar1
            // 
            trackBar1.Location = new Point(754, 425);
            trackBar1.Margin = new Padding(2, 2, 2, 2);
            trackBar1.Name = "trackBar1";
            trackBar1.Size = new Size(232, 45);
            trackBar1.TabIndex = 1;
            trackBar1.Scroll += trackBar1_Scroll;
            // 
            // InventoryPlaceholder
            // 
            InventoryPlaceholder.FormattingEnabled = true;
            InventoryPlaceholder.ItemHeight = 15;
            InventoryPlaceholder.Location = new Point(754, 7);
            InventoryPlaceholder.Margin = new Padding(2, 2, 2, 2);
            InventoryPlaceholder.Name = "InventoryPlaceholder";
            InventoryPlaceholder.Size = new Size(242, 214);
            InventoryPlaceholder.TabIndex = 2;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, aboutToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(4, 1, 0, 1);
            menuStrip1.Size = new Size(995, 24);
            menuStrip1.TabIndex = 3;
            menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem2, toolStripMenuItem3, loadToolStripMenuItem });
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(37, 22);
            toolStripMenuItem1.Text = "File";
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(132, 22);
            toolStripMenuItem2.Text = "New Game";
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(132, 22);
            toolStripMenuItem3.Text = "Save";
            toolStripMenuItem3.Click += toolStripMenuItem3_Click;
            // 
            // loadToolStripMenuItem
            // 
            loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            loadToolStripMenuItem.Size = new Size(132, 22);
            loadToolStripMenuItem.Text = "Load";
            // 
            // aboutToolStripMenuItem
            // 
            aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            aboutToolStripMenuItem.Size = new Size(52, 22);
            aboutToolStripMenuItem.Text = "About";
            // 
            // SpeedSliderText
            // 
            SpeedSliderText.BackgroundImage = Properties.Resources.GameSpeed;
            SpeedSliderText.BackgroundImageLayout = ImageLayout.Stretch;
            SpeedSliderText.Location = new Point(754, 394);
            SpeedSliderText.Margin = new Padding(2, 2, 2, 2);
            SpeedSliderText.Name = "SpeedSliderText";
            SpeedSliderText.Size = new Size(232, 28);
            SpeedSliderText.TabIndex = 5;
            SpeedSliderText.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = Properties.Resources.Sir_Blip;
            pictureBox3.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox3.Location = new Point(764, 38);
            pictureBox3.Margin = new Padding(2, 2, 2, 2);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(105, 86);
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.TwinShapedArmor;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(764, 127);
            pictureBox1.Margin = new Padding(2, 2, 2, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 86);
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources.PointyShapeSword;
            pictureBox2.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox2.Location = new Point(874, 38);
            pictureBox2.Margin = new Padding(2, 2, 2, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 86);
            pictureBox2.TabIndex = 12;
            pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = Properties.Resources.ProtectiveShape;
            pictureBox4.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox4.Location = new Point(874, 127);
            pictureBox4.Margin = new Padding(2, 2, 2, 2);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(105, 86);
            pictureBox4.TabIndex = 13;
            pictureBox4.TabStop = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Items.AddRange(new object[] { "Double-Shaped Chestplate : Defense 2 ", "Pointy-Arrow Sword : Attack 1", "Some-Type-Of-Gon Shield : Defense 1" });
            listBox1.Location = new Point(754, 223);
            listBox1.Margin = new Padding(2, 2, 2, 2);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(242, 94);
            listBox1.TabIndex = 14;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // GridDisplay
            // 
            GridDisplay.Controls.Add(pictureBox65);
            GridDisplay.Controls.Add(pictureBox66);
            GridDisplay.Controls.Add(pictureBox67);
            GridDisplay.Controls.Add(pictureBox68);
            GridDisplay.Controls.Add(pictureBox69);
            GridDisplay.Controls.Add(pictureBox70);
            GridDisplay.Controls.Add(pictureBox71);
            GridDisplay.Controls.Add(pictureBox72);
            GridDisplay.Controls.Add(pictureBox73);
            GridDisplay.Controls.Add(pictureBox74);
            GridDisplay.Controls.Add(pictureBox59);
            GridDisplay.Controls.Add(pictureBox60);
            GridDisplay.Controls.Add(pictureBox61);
            GridDisplay.Controls.Add(pictureBox62);
            GridDisplay.Controls.Add(pictureBox63);
            GridDisplay.Controls.Add(pictureBox64);
            GridDisplay.Controls.Add(pictureBox50);
            GridDisplay.Controls.Add(pictureBox51);
            GridDisplay.Controls.Add(pictureBox52);
            GridDisplay.Controls.Add(pictureBox53);
            GridDisplay.Controls.Add(pictureBox54);
            GridDisplay.Controls.Add(pictureBox55);
            GridDisplay.Controls.Add(pictureBox56);
            GridDisplay.Controls.Add(pictureBox57);
            GridDisplay.Controls.Add(pictureBox58);
            GridDisplay.Controls.Add(pictureBox41);
            GridDisplay.Controls.Add(pictureBox42);
            GridDisplay.Controls.Add(pictureBox43);
            GridDisplay.Controls.Add(pictureBox44);
            GridDisplay.Controls.Add(pictureBox45);
            GridDisplay.Controls.Add(pictureBox46);
            GridDisplay.Controls.Add(pictureBox47);
            GridDisplay.Controls.Add(pictureBox48);
            GridDisplay.Controls.Add(pictureBox49);
            GridDisplay.Controls.Add(pictureBox32);
            GridDisplay.Controls.Add(pictureBox33);
            GridDisplay.Controls.Add(pictureBox34);
            GridDisplay.Controls.Add(pictureBox35);
            GridDisplay.Controls.Add(pictureBox36);
            GridDisplay.Controls.Add(pictureBox37);
            GridDisplay.Controls.Add(pictureBox38);
            GridDisplay.Controls.Add(pictureBox39);
            GridDisplay.Controls.Add(pictureBox40);
            GridDisplay.Controls.Add(pictureBox23);
            GridDisplay.Controls.Add(pictureBox24);
            GridDisplay.Controls.Add(pictureBox25);
            GridDisplay.Controls.Add(pictureBox26);
            GridDisplay.Controls.Add(pictureBox27);
            GridDisplay.Controls.Add(pictureBox28);
            GridDisplay.Controls.Add(pictureBox29);
            GridDisplay.Controls.Add(pictureBox30);
            GridDisplay.Controls.Add(pictureBox31);
            GridDisplay.Controls.Add(pictureBox14);
            GridDisplay.Controls.Add(pictureBox15);
            GridDisplay.Controls.Add(pictureBox16);
            GridDisplay.Controls.Add(pictureBox17);
            GridDisplay.Controls.Add(pictureBox18);
            GridDisplay.Controls.Add(pictureBox19);
            GridDisplay.Controls.Add(pictureBox20);
            GridDisplay.Controls.Add(pictureBox21);
            GridDisplay.Controls.Add(pictureBox22);
            GridDisplay.Controls.Add(pictureBox13);
            GridDisplay.Controls.Add(pictureBox12);
            GridDisplay.Controls.Add(pictureBox11);
            GridDisplay.Controls.Add(pictureBox10);
            GridDisplay.Controls.Add(pictureBox9);
            GridDisplay.Controls.Add(pictureBox8);
            GridDisplay.Controls.Add(pictureBox7);
            GridDisplay.Controls.Add(pictureBox6);
            GridDisplay.Controls.Add(pictureBox5);
            GridDisplay.Location = new Point(6, 28);
            GridDisplay.Margin = new Padding(2, 2, 2, 2);
            GridDisplay.Name = "GridDisplay";
            GridDisplay.Size = new Size(744, 444);
            GridDisplay.TabIndex = 15;
            GridDisplay.Paint += GridDisplay_Paint;
            // 
            // pictureBox65
            // 
            pictureBox65.BackgroundImage = Properties.Resources.GridMadGuy;
            pictureBox65.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox65.Location = new Point(670, 382);
            pictureBox65.Margin = new Padding(2, 2, 2, 2);
            pictureBox65.Name = "pictureBox65";
            pictureBox65.Size = new Size(70, 60);
            pictureBox65.TabIndex = 69;
            pictureBox65.TabStop = false;
            // 
            // pictureBox66
            // 
            pictureBox66.BackgroundImage = Properties.Resources.GridChest;
            pictureBox66.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox66.Location = new Point(596, 382);
            pictureBox66.Margin = new Padding(2, 2, 2, 2);
            pictureBox66.Name = "pictureBox66";
            pictureBox66.Size = new Size(70, 60);
            pictureBox66.TabIndex = 68;
            pictureBox66.TabStop = false;
            // 
            // pictureBox67
            // 
            pictureBox67.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox67.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox67.Location = new Point(522, 382);
            pictureBox67.Margin = new Padding(2, 2, 2, 2);
            pictureBox67.Name = "pictureBox67";
            pictureBox67.Size = new Size(70, 60);
            pictureBox67.TabIndex = 67;
            pictureBox67.TabStop = false;
            // 
            // pictureBox68
            // 
            pictureBox68.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox68.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox68.Location = new Point(447, 382);
            pictureBox68.Margin = new Padding(2, 2, 2, 2);
            pictureBox68.Name = "pictureBox68";
            pictureBox68.Size = new Size(70, 60);
            pictureBox68.TabIndex = 66;
            pictureBox68.TabStop = false;
            // 
            // pictureBox69
            // 
            pictureBox69.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox69.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox69.Location = new Point(373, 382);
            pictureBox69.Margin = new Padding(2, 2, 2, 2);
            pictureBox69.Name = "pictureBox69";
            pictureBox69.Size = new Size(70, 60);
            pictureBox69.TabIndex = 65;
            pictureBox69.TabStop = false;
            // 
            // pictureBox70
            // 
            pictureBox70.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox70.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox70.Location = new Point(299, 382);
            pictureBox70.Margin = new Padding(2, 2, 2, 2);
            pictureBox70.Name = "pictureBox70";
            pictureBox70.Size = new Size(70, 60);
            pictureBox70.TabIndex = 64;
            pictureBox70.TabStop = false;
            // 
            // pictureBox71
            // 
            pictureBox71.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox71.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox71.Location = new Point(225, 382);
            pictureBox71.Margin = new Padding(2, 2, 2, 2);
            pictureBox71.Name = "pictureBox71";
            pictureBox71.Size = new Size(70, 60);
            pictureBox71.TabIndex = 63;
            pictureBox71.TabStop = false;
            // 
            // pictureBox72
            // 
            pictureBox72.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox72.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox72.Location = new Point(150, 382);
            pictureBox72.Margin = new Padding(2, 2, 2, 2);
            pictureBox72.Name = "pictureBox72";
            pictureBox72.Size = new Size(70, 60);
            pictureBox72.TabIndex = 62;
            pictureBox72.TabStop = false;
            // 
            // pictureBox73
            // 
            pictureBox73.BackgroundImage = Properties.Resources.GridTree;
            pictureBox73.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox73.Location = new Point(76, 382);
            pictureBox73.Margin = new Padding(2, 2, 2, 2);
            pictureBox73.Name = "pictureBox73";
            pictureBox73.Size = new Size(70, 60);
            pictureBox73.TabIndex = 61;
            pictureBox73.TabStop = false;
            // 
            // pictureBox74
            // 
            pictureBox74.BackgroundImage = Properties.Resources.GridTree;
            pictureBox74.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox74.Location = new Point(2, 382);
            pictureBox74.Margin = new Padding(2, 2, 2, 2);
            pictureBox74.Name = "pictureBox74";
            pictureBox74.Size = new Size(70, 60);
            pictureBox74.TabIndex = 60;
            pictureBox74.TabStop = false;
            // 
            // pictureBox59
            // 
            pictureBox59.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox59.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox59.Location = new Point(670, 318);
            pictureBox59.Margin = new Padding(2, 2, 2, 2);
            pictureBox59.Name = "pictureBox59";
            pictureBox59.Size = new Size(70, 60);
            pictureBox59.TabIndex = 59;
            pictureBox59.TabStop = false;
            // 
            // pictureBox60
            // 
            pictureBox60.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox60.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox60.Location = new Point(670, 254);
            pictureBox60.Margin = new Padding(2, 2, 2, 2);
            pictureBox60.Name = "pictureBox60";
            pictureBox60.Size = new Size(70, 60);
            pictureBox60.TabIndex = 58;
            pictureBox60.TabStop = false;
            // 
            // pictureBox61
            // 
            pictureBox61.BackgroundImage = Properties.Resources.GridSnake;
            pictureBox61.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox61.Location = new Point(670, 191);
            pictureBox61.Margin = new Padding(2, 2, 2, 2);
            pictureBox61.Name = "pictureBox61";
            pictureBox61.Size = new Size(70, 60);
            pictureBox61.TabIndex = 57;
            pictureBox61.TabStop = false;
            // 
            // pictureBox62
            // 
            pictureBox62.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox62.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox62.Location = new Point(670, 127);
            pictureBox62.Margin = new Padding(2, 2, 2, 2);
            pictureBox62.Name = "pictureBox62";
            pictureBox62.Size = new Size(70, 60);
            pictureBox62.TabIndex = 56;
            pictureBox62.TabStop = false;
            // 
            // pictureBox63
            // 
            pictureBox63.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox63.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox63.Location = new Point(670, 64);
            pictureBox63.Margin = new Padding(2, 2, 2, 2);
            pictureBox63.Name = "pictureBox63";
            pictureBox63.Size = new Size(70, 60);
            pictureBox63.TabIndex = 55;
            pictureBox63.TabStop = false;
            // 
            // pictureBox64
            // 
            pictureBox64.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox64.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox64.Location = new Point(670, 0);
            pictureBox64.Margin = new Padding(2, 2, 2, 2);
            pictureBox64.Name = "pictureBox64";
            pictureBox64.Size = new Size(70, 60);
            pictureBox64.TabIndex = 54;
            pictureBox64.TabStop = false;
            // 
            // pictureBox50
            // 
            pictureBox50.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox50.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox50.Location = new Point(596, 318);
            pictureBox50.Margin = new Padding(2, 2, 2, 2);
            pictureBox50.Name = "pictureBox50";
            pictureBox50.Size = new Size(70, 60);
            pictureBox50.TabIndex = 53;
            pictureBox50.TabStop = false;
            // 
            // pictureBox51
            // 
            pictureBox51.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox51.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox51.Location = new Point(522, 318);
            pictureBox51.Margin = new Padding(2, 2, 2, 2);
            pictureBox51.Name = "pictureBox51";
            pictureBox51.Size = new Size(70, 60);
            pictureBox51.TabIndex = 52;
            pictureBox51.TabStop = false;
            // 
            // pictureBox52
            // 
            pictureBox52.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox52.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox52.Location = new Point(447, 318);
            pictureBox52.Margin = new Padding(2, 2, 2, 2);
            pictureBox52.Name = "pictureBox52";
            pictureBox52.Size = new Size(70, 60);
            pictureBox52.TabIndex = 51;
            pictureBox52.TabStop = false;
            // 
            // pictureBox53
            // 
            pictureBox53.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox53.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox53.Location = new Point(373, 318);
            pictureBox53.Margin = new Padding(2, 2, 2, 2);
            pictureBox53.Name = "pictureBox53";
            pictureBox53.Size = new Size(70, 60);
            pictureBox53.TabIndex = 50;
            pictureBox53.TabStop = false;
            // 
            // pictureBox54
            // 
            pictureBox54.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox54.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox54.Location = new Point(299, 318);
            pictureBox54.Margin = new Padding(2, 2, 2, 2);
            pictureBox54.Name = "pictureBox54";
            pictureBox54.Size = new Size(70, 60);
            pictureBox54.TabIndex = 49;
            pictureBox54.TabStop = false;
            // 
            // pictureBox55
            // 
            pictureBox55.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox55.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox55.Location = new Point(225, 318);
            pictureBox55.Margin = new Padding(2, 2, 2, 2);
            pictureBox55.Name = "pictureBox55";
            pictureBox55.Size = new Size(70, 60);
            pictureBox55.TabIndex = 48;
            pictureBox55.TabStop = false;
            // 
            // pictureBox56
            // 
            pictureBox56.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox56.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox56.Location = new Point(150, 318);
            pictureBox56.Margin = new Padding(2, 2, 2, 2);
            pictureBox56.Name = "pictureBox56";
            pictureBox56.Size = new Size(70, 60);
            pictureBox56.TabIndex = 47;
            pictureBox56.TabStop = false;
            // 
            // pictureBox57
            // 
            pictureBox57.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox57.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox57.Location = new Point(76, 318);
            pictureBox57.Margin = new Padding(2, 2, 2, 2);
            pictureBox57.Name = "pictureBox57";
            pictureBox57.Size = new Size(70, 60);
            pictureBox57.TabIndex = 46;
            pictureBox57.TabStop = false;
            // 
            // pictureBox58
            // 
            pictureBox58.BackgroundImage = Properties.Resources.GridTree;
            pictureBox58.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox58.Location = new Point(2, 318);
            pictureBox58.Margin = new Padding(2, 2, 2, 2);
            pictureBox58.Name = "pictureBox58";
            pictureBox58.Size = new Size(70, 60);
            pictureBox58.TabIndex = 45;
            pictureBox58.TabStop = false;
            // 
            // pictureBox41
            // 
            pictureBox41.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox41.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox41.Location = new Point(596, 254);
            pictureBox41.Margin = new Padding(2, 2, 2, 2);
            pictureBox41.Name = "pictureBox41";
            pictureBox41.Size = new Size(70, 60);
            pictureBox41.TabIndex = 44;
            pictureBox41.TabStop = false;
            // 
            // pictureBox42
            // 
            pictureBox42.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox42.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox42.Location = new Point(522, 254);
            pictureBox42.Margin = new Padding(2, 2, 2, 2);
            pictureBox42.Name = "pictureBox42";
            pictureBox42.Size = new Size(70, 60);
            pictureBox42.TabIndex = 43;
            pictureBox42.TabStop = false;
            // 
            // pictureBox43
            // 
            pictureBox43.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox43.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox43.Location = new Point(447, 254);
            pictureBox43.Margin = new Padding(2, 2, 2, 2);
            pictureBox43.Name = "pictureBox43";
            pictureBox43.Size = new Size(70, 60);
            pictureBox43.TabIndex = 42;
            pictureBox43.TabStop = false;
            // 
            // pictureBox44
            // 
            pictureBox44.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox44.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox44.Location = new Point(373, 254);
            pictureBox44.Margin = new Padding(2, 2, 2, 2);
            pictureBox44.Name = "pictureBox44";
            pictureBox44.Size = new Size(70, 60);
            pictureBox44.TabIndex = 41;
            pictureBox44.TabStop = false;
            // 
            // pictureBox45
            // 
            pictureBox45.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox45.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox45.Location = new Point(299, 254);
            pictureBox45.Margin = new Padding(2, 2, 2, 2);
            pictureBox45.Name = "pictureBox45";
            pictureBox45.Size = new Size(70, 60);
            pictureBox45.TabIndex = 40;
            pictureBox45.TabStop = false;
            // 
            // pictureBox46
            // 
            pictureBox46.BackgroundImage = Properties.Resources.GridSnake;
            pictureBox46.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox46.Location = new Point(225, 254);
            pictureBox46.Margin = new Padding(2, 2, 2, 2);
            pictureBox46.Name = "pictureBox46";
            pictureBox46.Size = new Size(70, 60);
            pictureBox46.TabIndex = 39;
            pictureBox46.TabStop = false;
            // 
            // pictureBox47
            // 
            pictureBox47.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox47.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox47.Location = new Point(150, 254);
            pictureBox47.Margin = new Padding(2, 2, 2, 2);
            pictureBox47.Name = "pictureBox47";
            pictureBox47.Size = new Size(70, 60);
            pictureBox47.TabIndex = 38;
            pictureBox47.TabStop = false;
            // 
            // pictureBox48
            // 
            pictureBox48.BackgroundImage = Properties.Resources.GridChest;
            pictureBox48.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox48.Location = new Point(76, 254);
            pictureBox48.Margin = new Padding(2, 2, 2, 2);
            pictureBox48.Name = "pictureBox48";
            pictureBox48.Size = new Size(70, 60);
            pictureBox48.TabIndex = 37;
            pictureBox48.TabStop = false;
            // 
            // pictureBox49
            // 
            pictureBox49.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox49.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox49.Location = new Point(2, 254);
            pictureBox49.Margin = new Padding(2, 2, 2, 2);
            pictureBox49.Name = "pictureBox49";
            pictureBox49.Size = new Size(70, 60);
            pictureBox49.TabIndex = 36;
            pictureBox49.TabStop = false;
            // 
            // pictureBox32
            // 
            pictureBox32.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox32.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox32.Location = new Point(596, 191);
            pictureBox32.Margin = new Padding(2, 2, 2, 2);
            pictureBox32.Name = "pictureBox32";
            pictureBox32.Size = new Size(70, 60);
            pictureBox32.TabIndex = 35;
            pictureBox32.TabStop = false;
            // 
            // pictureBox33
            // 
            pictureBox33.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox33.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox33.Location = new Point(522, 191);
            pictureBox33.Margin = new Padding(2, 2, 2, 2);
            pictureBox33.Name = "pictureBox33";
            pictureBox33.Size = new Size(70, 60);
            pictureBox33.TabIndex = 34;
            pictureBox33.TabStop = false;
            // 
            // pictureBox34
            // 
            pictureBox34.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox34.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox34.Location = new Point(447, 191);
            pictureBox34.Margin = new Padding(2, 2, 2, 2);
            pictureBox34.Name = "pictureBox34";
            pictureBox34.Size = new Size(70, 60);
            pictureBox34.TabIndex = 33;
            pictureBox34.TabStop = false;
            // 
            // pictureBox35
            // 
            pictureBox35.BackgroundImage = Properties.Resources.GridSirBlip;
            pictureBox35.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox35.Location = new Point(373, 191);
            pictureBox35.Margin = new Padding(2, 2, 2, 2);
            pictureBox35.Name = "pictureBox35";
            pictureBox35.Size = new Size(70, 60);
            pictureBox35.TabIndex = 32;
            pictureBox35.TabStop = false;
            // 
            // pictureBox36
            // 
            pictureBox36.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox36.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox36.Location = new Point(299, 191);
            pictureBox36.Margin = new Padding(2, 2, 2, 2);
            pictureBox36.Name = "pictureBox36";
            pictureBox36.Size = new Size(70, 60);
            pictureBox36.TabIndex = 31;
            pictureBox36.TabStop = false;
            // 
            // pictureBox37
            // 
            pictureBox37.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox37.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox37.Location = new Point(225, 191);
            pictureBox37.Margin = new Padding(2, 2, 2, 2);
            pictureBox37.Name = "pictureBox37";
            pictureBox37.Size = new Size(70, 60);
            pictureBox37.TabIndex = 30;
            pictureBox37.TabStop = false;
            // 
            // pictureBox38
            // 
            pictureBox38.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox38.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox38.Location = new Point(150, 191);
            pictureBox38.Margin = new Padding(2, 2, 2, 2);
            pictureBox38.Name = "pictureBox38";
            pictureBox38.Size = new Size(70, 60);
            pictureBox38.TabIndex = 29;
            pictureBox38.TabStop = false;
            // 
            // pictureBox39
            // 
            pictureBox39.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox39.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox39.Location = new Point(76, 191);
            pictureBox39.Margin = new Padding(2, 2, 2, 2);
            pictureBox39.Name = "pictureBox39";
            pictureBox39.Size = new Size(70, 60);
            pictureBox39.TabIndex = 28;
            pictureBox39.TabStop = false;
            // 
            // pictureBox40
            // 
            pictureBox40.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox40.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox40.Location = new Point(2, 191);
            pictureBox40.Margin = new Padding(2, 2, 2, 2);
            pictureBox40.Name = "pictureBox40";
            pictureBox40.Size = new Size(70, 60);
            pictureBox40.TabIndex = 27;
            pictureBox40.TabStop = false;
            // 
            // pictureBox23
            // 
            pictureBox23.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox23.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox23.Location = new Point(596, 127);
            pictureBox23.Margin = new Padding(2, 2, 2, 2);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new Size(70, 60);
            pictureBox23.TabIndex = 26;
            pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            pictureBox24.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox24.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox24.Location = new Point(522, 127);
            pictureBox24.Margin = new Padding(2, 2, 2, 2);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new Size(70, 60);
            pictureBox24.TabIndex = 25;
            pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            pictureBox25.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox25.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox25.Location = new Point(447, 127);
            pictureBox25.Margin = new Padding(2, 2, 2, 2);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(70, 60);
            pictureBox25.TabIndex = 24;
            pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            pictureBox26.BackgroundImage = Properties.Resources.GridTree;
            pictureBox26.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox26.Location = new Point(373, 127);
            pictureBox26.Margin = new Padding(2, 2, 2, 2);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new Size(70, 60);
            pictureBox26.TabIndex = 23;
            pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            pictureBox27.BackgroundImage = Properties.Resources.GridTree;
            pictureBox27.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox27.Location = new Point(299, 127);
            pictureBox27.Margin = new Padding(2, 2, 2, 2);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new Size(70, 60);
            pictureBox27.TabIndex = 22;
            pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            pictureBox28.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox28.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox28.Location = new Point(225, 127);
            pictureBox28.Margin = new Padding(2, 2, 2, 2);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new Size(70, 60);
            pictureBox28.TabIndex = 21;
            pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            pictureBox29.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox29.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox29.Location = new Point(150, 127);
            pictureBox29.Margin = new Padding(2, 2, 2, 2);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new Size(70, 60);
            pictureBox29.TabIndex = 20;
            pictureBox29.TabStop = false;
            // 
            // pictureBox30
            // 
            pictureBox30.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox30.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox30.Location = new Point(76, 127);
            pictureBox30.Margin = new Padding(2, 2, 2, 2);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new Size(70, 60);
            pictureBox30.TabIndex = 19;
            pictureBox30.TabStop = false;
            // 
            // pictureBox31
            // 
            pictureBox31.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox31.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox31.Location = new Point(2, 127);
            pictureBox31.Margin = new Padding(2, 2, 2, 2);
            pictureBox31.Name = "pictureBox31";
            pictureBox31.Size = new Size(70, 60);
            pictureBox31.TabIndex = 18;
            pictureBox31.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox14.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox14.Location = new Point(596, 64);
            pictureBox14.Margin = new Padding(2, 2, 2, 2);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(70, 60);
            pictureBox14.TabIndex = 17;
            pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            pictureBox15.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox15.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox15.Location = new Point(522, 64);
            pictureBox15.Margin = new Padding(2, 2, 2, 2);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(70, 60);
            pictureBox15.TabIndex = 16;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.BackgroundImage = Properties.Resources.GridTree;
            pictureBox16.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox16.Location = new Point(447, 64);
            pictureBox16.Margin = new Padding(2, 2, 2, 2);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(70, 60);
            pictureBox16.TabIndex = 15;
            pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            pictureBox17.BackgroundImage = Properties.Resources.GridTree;
            pictureBox17.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox17.Location = new Point(373, 64);
            pictureBox17.Margin = new Padding(2, 2, 2, 2);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(70, 60);
            pictureBox17.TabIndex = 14;
            pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            pictureBox18.BackgroundImage = Properties.Resources.GridTree;
            pictureBox18.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox18.Location = new Point(299, 64);
            pictureBox18.Margin = new Padding(2, 2, 2, 2);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(70, 60);
            pictureBox18.TabIndex = 13;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox19.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox19.Location = new Point(225, 64);
            pictureBox19.Margin = new Padding(2, 2, 2, 2);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(70, 60);
            pictureBox19.TabIndex = 12;
            pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            pictureBox20.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox20.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox20.Location = new Point(150, 64);
            pictureBox20.Margin = new Padding(2, 2, 2, 2);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(70, 60);
            pictureBox20.TabIndex = 11;
            pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            pictureBox21.BackgroundImage = Properties.Resources.GridMadGuy;
            pictureBox21.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox21.Location = new Point(76, 64);
            pictureBox21.Margin = new Padding(2, 2, 2, 2);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new Size(70, 60);
            pictureBox21.TabIndex = 10;
            pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            pictureBox22.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox22.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox22.Location = new Point(2, 64);
            pictureBox22.Margin = new Padding(2, 2, 2, 2);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new Size(70, 60);
            pictureBox22.TabIndex = 9;
            pictureBox22.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox13.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox13.Location = new Point(596, 0);
            pictureBox13.Margin = new Padding(2, 2, 2, 2);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(70, 60);
            pictureBox13.TabIndex = 8;
            pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackgroundImage = Properties.Resources.GridChest;
            pictureBox12.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox12.Location = new Point(522, 0);
            pictureBox12.Margin = new Padding(2, 2, 2, 2);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(70, 60);
            pictureBox12.TabIndex = 7;
            pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackgroundImage = Properties.Resources.GridTree;
            pictureBox11.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox11.Location = new Point(447, 0);
            pictureBox11.Margin = new Padding(2, 2, 2, 2);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(70, 60);
            pictureBox11.TabIndex = 6;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox10.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox10.Location = new Point(373, 0);
            pictureBox10.Margin = new Padding(2, 2, 2, 2);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(70, 60);
            pictureBox10.TabIndex = 5;
            pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox9.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox9.Location = new Point(299, 0);
            pictureBox9.Margin = new Padding(2, 2, 2, 2);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(70, 60);
            pictureBox9.TabIndex = 4;
            pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox8.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox8.Location = new Point(225, 0);
            pictureBox8.Margin = new Padding(2, 2, 2, 2);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(70, 60);
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox7.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox7.Location = new Point(150, 0);
            pictureBox7.Margin = new Padding(2, 2, 2, 2);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(70, 60);
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImage = Properties.Resources.GridMountain;
            pictureBox6.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox6.Location = new Point(76, 0);
            pictureBox6.Margin = new Padding(2, 2, 2, 2);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(70, 60);
            pictureBox6.TabIndex = 1;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImage = Properties.Resources.Grid_Tile;
            pictureBox5.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox5.Location = new Point(2, 0);
            pictureBox5.Margin = new Padding(2, 2, 2, 2);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(70, 60);
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Items.AddRange(new object[] { "Sir Blip adventurously headed north!" });
            listBox2.Location = new Point(754, 319);
            listBox2.Margin = new Padding(2, 2, 2, 2);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(242, 64);
            listBox2.TabIndex = 16;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(995, 474);
            Controls.Add(listBox2);
            Controls.Add(GridDisplay);
            Controls.Add(listBox1);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(SpeedSliderText);
            Controls.Add(InventoryPlaceholder);
            Controls.Add(trackBar1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)trackBar1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)SpeedSliderText).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            GridDisplay.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox65).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox66).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox67).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox68).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox69).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox70).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox71).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox72).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox73).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox74).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox59).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox60).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox61).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox62).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox63).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox64).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox50).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox51).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox52).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox53).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox54).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox55).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox56).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox57).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox58).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox41).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox42).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox43).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox44).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox45).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox46).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox47).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox48).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox49).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox34).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox35).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox36).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox37).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox38).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox39).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox40).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TrackBar trackBar1;
        private ListBox InventoryPlaceholder;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private PictureBox SpeedSliderText;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox4;
        private ListBox listBox1;
        private Panel GridDisplay;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox65;
        private PictureBox pictureBox66;
        private PictureBox pictureBox67;
        private PictureBox pictureBox68;
        private PictureBox pictureBox69;
        private PictureBox pictureBox70;
        private PictureBox pictureBox71;
        private PictureBox pictureBox72;
        private PictureBox pictureBox73;
        private PictureBox pictureBox74;
        private PictureBox pictureBox59;
        private PictureBox pictureBox60;
        private PictureBox pictureBox61;
        private PictureBox pictureBox62;
        private PictureBox pictureBox63;
        private PictureBox pictureBox64;
        private PictureBox pictureBox50;
        private PictureBox pictureBox51;
        private PictureBox pictureBox52;
        private PictureBox pictureBox53;
        private PictureBox pictureBox54;
        private PictureBox pictureBox55;
        private PictureBox pictureBox56;
        private PictureBox pictureBox57;
        private PictureBox pictureBox58;
        private PictureBox pictureBox41;
        private PictureBox pictureBox42;
        private PictureBox pictureBox43;
        private PictureBox pictureBox44;
        private PictureBox pictureBox45;
        private PictureBox pictureBox46;
        private PictureBox pictureBox47;
        private PictureBox pictureBox48;
        private PictureBox pictureBox49;
        private PictureBox pictureBox32;
        private PictureBox pictureBox33;
        private PictureBox pictureBox34;
        private PictureBox pictureBox35;
        private PictureBox pictureBox36;
        private PictureBox pictureBox37;
        private PictureBox pictureBox38;
        private PictureBox pictureBox39;
        private PictureBox pictureBox40;
        private PictureBox pictureBox23;
        private PictureBox pictureBox24;
        private PictureBox pictureBox25;
        private PictureBox pictureBox26;
        private PictureBox pictureBox27;
        private PictureBox pictureBox28;
        private PictureBox pictureBox29;
        private PictureBox pictureBox30;
        private PictureBox pictureBox31;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private PictureBox pictureBox21;
        private PictureBox pictureBox22;
        private PictureBox pictureBox13;
        private PictureBox pictureBox12;
        private PictureBox pictureBox11;
        private PictureBox pictureBox10;
        private PictureBox pictureBox9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private ToolStripMenuItem loadToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ListBox listBox2;
    }
}
