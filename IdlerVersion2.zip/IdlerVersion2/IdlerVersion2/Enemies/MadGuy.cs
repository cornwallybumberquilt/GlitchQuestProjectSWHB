﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
using IdlerVersion2.Inventory;

namespace IdlerVersion2.Enemies
{
    /// <summary>
    /// Creates an instance of an enemy object
    /// </summary>
    internal class MadGuy : Square
    {
        public int _attack;
        public int _defense;
        public MadGuy(int size) : base(size)
        {
            _attack = 2;
            _defense = 1;
            _deadEnemy = true;
        }

        public override Blip OccupiedEvent(Blip blip)
        {
            if (_deadEnemy == true)
            {
                blip.RecentActions.Add($"{blip.Name} found some dead guy and wonders how that happened.");
                return blip;
            }
            blip.RecentActions.Add($"{blip.Name} was attacked by a Mad Guy!");
            int damage = _attack - blip.defense;
            blip.TakeDamage(damage);
            if (blip.attack > _defense) 
            { 
            _deadEnemy = true;
                blip.RecentActions.Add($"{blip.Name} took {damage} damage but defeated the Mad Guy!");
                blip.inventory.Add(new Weapon("Okay Sword", 2));
                blip.RecentActions.Add($"The Mad Guy dropped some cool stuff.");
            }
            else 
            {
                blip.RecentActions.Add($"{blip.Name} took {damage} damage but was too weak to harm the Mad Guy.");
            }
            return blip;
        }

    }
}
