﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Enemies
{
    /// <summary>
    /// Creates an instance of an enemy object
    /// </summary>
    internal class Enemy : Square
    {
        protected int _attack;
        protected int _defense;
        public bool _alive;
        public Enemy(int size) : base(size)
        {
            _alive = true;
        }

        public void HandleCollision()
        {
            throw new NotImplementedException();
        }
    }
}
