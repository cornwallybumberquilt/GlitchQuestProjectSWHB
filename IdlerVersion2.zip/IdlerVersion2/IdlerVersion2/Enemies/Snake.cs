﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
using IdlerVersion2.Inventory;

namespace IdlerVersion2.Enemies
{
    /// <summary>
    /// Creates an instance of an enemy object
    /// </summary>
    internal class Snake : Square
    {
        public int _attack;
        public int _defense;
        public Snake(int size) : base(size)
        {
            _attack = 1;
            _defense = -1;
        }

        public override Blip OccupiedEvent(Blip blip)
        {
            if (_deadEnemy == true) 
            {
                blip.RecentActions.Add($"{blip.Name} found a memorial for a dead snake");
                return blip;
            }
            blip.RecentActions.Add($"{blip.Name} was bit by a snake!");
            int damage = _attack - blip.defense;
            blip.TakeDamage( damage );
            if (blip.attack > _defense)
            {
                _deadEnemy = true;
                blip.RecentActions.Add($"{blip.Name} took {damage} damage but squashed the snake");
                blip.inventory.Add(new Weapon("Snake Whip", 2));
                blip.RecentActions.Add($"Maybe {blip.Name} can use the snake for something...");
            }
            else
            {
                blip.RecentActions.Add($"{blip.Name} took {damage} damage but the snakes scales were too thick to harm!");
            }
            return blip;
        }
    }
}
