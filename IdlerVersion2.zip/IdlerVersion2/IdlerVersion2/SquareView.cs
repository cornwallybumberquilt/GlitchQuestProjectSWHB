﻿using IdlerVersion2.Enemies;
using IdlerVersion2.Environments;

namespace IdlerVersion2
{
    /// <summary>
    /// creates an object meant to display a cell on a grid
    /// </summary>
    public class SquareView : Panel
    {
        public Square _square;
        public SquareView(Square square)
        {
            _square = square;

        }

        public void Draw(int x, int y, int xSize, int ySize)
        {
            _square._x = x;
            _square._y = y;
            Size = new Size(xSize, ySize);
            Location = new Point(xSize * x, ySize * y);

            Visible = true;


            if (_square._occupied == true)
            {
                BackgroundImage = Properties.Resources.GridSirBlip;
            }
            /*else if (_square is MadGuy) 
            { 
            //if (_square. == true) { }
            }
            */
            else if (_square is Mountain)
            {
                BackgroundImage = Properties.Resources.GridMountain;
            }
            else if (_square is Tree)
            {
                BackgroundImage = Properties.Resources.GridTree;
            }
            else if (_square is Desert)
            {
                BackgroundImage = Properties.Resources.GridDesert;
            }
            else if (_square is MadGuy) 
            {
                if (_square._deadEnemy == true)
                {
                    BackgroundImage = Properties.Resources.Grid_Tile;
                }
                else
                {
                    BackgroundImage = Properties.Resources.GridMadGuy;
                }
            }
            else if (_square is Snake)
            {
                if (_square._deadEnemy == true)
                {
                    BackgroundImage = Properties.Resources.Grid_Tile;
                }
                else
                {
                    BackgroundImage = Properties.Resources.GridSnake;
                }
            }

            else
            {
                BackgroundImage = Properties.Resources.Grid_Tile;

            }
            BackgroundImageLayout = ImageLayout.Stretch;
        }

    }
}
