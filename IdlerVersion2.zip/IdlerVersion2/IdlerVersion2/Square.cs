﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2
{
    /// <summary>
    /// Creates an instance of a square to display on the grid
    /// </summary>
    public class Square
    {
        public string Name;
        public int _size;
        public int _x;
        public int _y;
        public bool _occupied;
        public bool _wasOccupied;
        public bool _deadEnemy;

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="size"></param>
        public Square(int size)
        {
            Name = "";
            _size = size;
            _occupied = false;
            _wasOccupied = false;
        }
        /// <summary>
        /// Adds travel string to blips recent actions list
        /// </summary>
        /// <param name="blip"></param>
        /// <returns></returns>
        public virtual Blip OccupiedEvent(Blip blip)
        {
            return blip;
        }

    }

}
