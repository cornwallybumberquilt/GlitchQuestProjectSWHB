﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a puddle environment object
    /// </summary>
    internal class Puddle : Square
    {
        public Puddle(int size) : base(size) { }

        public void HandleCollision() { }
    }
}
