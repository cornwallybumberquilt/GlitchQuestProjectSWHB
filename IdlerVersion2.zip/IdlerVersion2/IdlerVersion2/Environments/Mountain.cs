﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
using IdlerVersion2.Inventory;

namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a mountain environment object
    /// </summary>
    internal class Mountain : Square
    {
        public Mountain(int size) : base(size) { }

        public override Blip OccupiedEvent(Blip blip)
        {

            blip.RecentActions.Add($"{blip.Name} was turned back by a mountain!");
            return blip;
        }
    }
}
