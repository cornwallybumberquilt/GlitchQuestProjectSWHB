﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of an environment object
    /// </summary>
    internal class Environment : Square
    {
        public Environment(int size) : base(size) { }

        public virtual Blip OccupiedEvent(Blip blip)
        {
            blip.RecentActions.Add($"{blip.Name} traveled into an empty field!");
            return blip;
        }
    }
}
