﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a desert environment object
    /// </summary>
    internal class Desert : Square
    {
        public Desert(int size) : base(size) { }

        public override Blip OccupiedEvent(Blip blip)
        {
            blip.RecentActions.Add($"{blip.Name} traveled into a really hot desert and took 10 damage");
            blip.health -= 10;
            if ( blip.health < 0 ) { blip.health = 0; }
            return blip;
        }
    }
}

