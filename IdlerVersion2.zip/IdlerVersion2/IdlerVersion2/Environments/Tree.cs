﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
using IdlerVersion2.Inventory;

namespace IdlerVersion2.Environments
{
    /// <summary>
    /// Creates an instance of a tree environment object
    /// </summary>
    internal class Tree : Square
    {
        public Tree(int size) : base(size) { }

        public override Blip OccupiedEvent(Blip blip)
        {

            blip.RecentActions.Add($"{blip.Name} traveled into a forest and found food!");
            Food apple = new Food("Apple", 10);
            blip.inventory.Add(apple);
            return blip;
        }
    }
}
