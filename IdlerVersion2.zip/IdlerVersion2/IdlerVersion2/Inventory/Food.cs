﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Inventory
{
    internal class Food : Item
    {
        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="name"></param>
        /// <param name="foodpoints"></param>
        public Food(string name, int foodpoints) : base(name, foodpoints)
        {
        }


        public void ItemEffect()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// ToString override to better display food object
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Food: {_name}  -   Calories: {_points}";
        }
    }
}
