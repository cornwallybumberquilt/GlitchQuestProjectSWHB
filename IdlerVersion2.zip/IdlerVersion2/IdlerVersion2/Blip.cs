﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
using IdlerVersion2.Environments;
using IdlerVersion2.Inventory;
using System.Linq.Expressions;

namespace IdlerVersion2
{
    /// <summary>
    /// Creates an instance of the blip object
    /// </summary>
    public class Blip
    {
        public string Name;
        public int _x;
        public int _y;
        int actionCooldown;
        int currentActionCooldown;
        public List<(int, int)> validMoves;
        public List<string> RecentActions;
        public Inventory.Inventory inventory;
        Armor armor;
        Weapon weapon;
        Shield shield;
        public int maxHunger;
        public int hunger;
        public int maxTired;
        public int tired;
        public int happiness;
        public int maxHealth;
        public int health;
        public int defense;
        public int attack;
        public int deathCounter;
        public int LastAction;
        Bitmap icon;

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="size"></param>
        /// <param name="actionCooldownSeconds"></param>
        public Blip(int size, int actionCooldownSeconds)
        {
            Name = "Blip";
            RecentActions = new List<string>();
            this.actionCooldown = actionCooldownSeconds;
            this.currentActionCooldown = actionCooldown;
            this.validMoves = new List<(int, int)>();
            inventory = new Inventory.Inventory();
            _x = 0;
            _y = 0;
            inventory.Add(new Food("Apple", 10));
            shield = new Shield("Bad Shield", 0);
            armor = new Armor("Bad Armor", 0);
            weapon = new Weapon("Bad Sword", 0);
            inventory.Add(new Potion("Mysterious Drink", 0));
            maxTired = 20;
            maxHunger = 100;
            hunger = 80;
            tired = 20;
            maxHealth = 100;
            health = 1;
            deathCounter = 0;
            LastAction = 0;
        }
        /// <summary>
        /// Updates blips position on the grid
        /// </summary>
        public bool Update()
        {
            bool performedAction = false;
            string message = "";
            if (currentActionCooldown <= actionCooldown)
            {

                Random r = new Random();
                bool canEquip = false;

                for (int i = 0; i < inventory.items.Count; i++)
                {
                    if (inventory.items[i] is Equipment)
                    {
                        canEquip = true;
                    }
                }


                int actionChoice = r.Next(0, 4);
                LastAction = actionChoice;
                if (actionChoice == 0 && inventory.foodCount > 0) { Eat(); }
                else if (actionChoice == 1 && inventory.potionCount > 0) { DrinkPotion(); }
                else if (actionChoice == 2) { Sleep(); }
                else if (actionChoice == 3 && canEquip == true) { Equip(); }
                else
                {
                    performedAction = Move();
                }
                if (hunger > 0)
                {
                    hunger -= 1;
                }
                if (tired > 0)
                {
                    tired -= 1;
                }
            }
            int hungerPercent = (hunger * 100) / maxHunger;
            int tiredPercent = (tired * 100) / maxTired;
            if (hungerPercent > tiredPercent)
            {
                happiness = hungerPercent;
            }
            else
            {
                happiness = tiredPercent;
            }
            currentActionCooldown -= (1 * happiness) / 100;
            return performedAction;
        }
        /// <summary>
        /// Updates list of valid moves for Blip
        /// </summary>
        /// <param name="squares"></param>
        public void GetAdjacentCells(List<Square> squares)
        {
            int movementModifier = 1;


            List<(int, int)> adjacentCells = new List<(int, int)>();
            for (int i = 0; i < squares.Count; i++)
            {
                for (int j = 0; j < squares.Count; j++)
                {
                    if ((squares[j]._x >= this._x - movementModifier && squares[j]._x <= this._x + movementModifier) && (squares[j]._y >= this._y - movementModifier && squares[j]._y <= this._y + movementModifier))
                    {
                        if (adjacentCells.Contains((squares[j]._x, squares[j]._y)) || (squares[j]._x, squares[j]._y) == (_x, _y)) { continue; }
                        if (squares[j] is Mountain) { continue; }
                        adjacentCells.Add((squares[j]._x, squares[j]._y));
                    }
                }
            }
            validMoves = adjacentCells;
        }
        /// <summary>
        /// Moves blip on the grid
        /// </summary>
        /// <returns></returns>
        public bool Move()
        {
            Random r = new Random();
            int moveChoice = (validMoves.Count());
            moveChoice = r.Next(moveChoice);

            _x = validMoves[moveChoice].Item1;
            _y = validMoves[moveChoice].Item2;
            return true;
        }
        /// <summary>
        /// Method for blip to eat food from inventory
        /// </summary>
        public void Eat()
        {
            string message = "Food?";
            for (int i = 0; i < inventory.items.Count; i++)
            {
                if (inventory.items[i] is Food)
                {

                    hunger += inventory.items[i]._points;
                    if (hunger > 100) { hunger = 100; }
                    message = $"{Name} devoured the {inventory.items[i]._name} and restored {inventory.items[i]._points} of hunger!";
                    inventory.Remove(inventory.items[i]);

                    break;
                }
            }
            RecentActions.Add(message);
        }
        /// <summary>
        /// Method for making blip sleep to restored tired meter
        /// </summary>
        public void Sleep()
        {
            tired = maxTired;
            RecentActions.Add($"{Name} took a nap and is now fully rested!");
        }
        /// <summary>
        /// Inflicts damage on the blip
        /// </summary>
        /// <param name="damage"></param>
        public void TakeDamage(int damage) 
        { 
        if(health - damage > 0) 
            { 
            health -= damage;
            }
            else 
            {
                health = 0;
            }
        }

        /// <summary>
        /// Method for making blip drink potions
        /// </summary>
        public void DrinkPotion()
        {
            string message = "potion?";
            for (int i = 0; i < inventory.items.Count; i++)
            {
                if (inventory.items[i] is Potion)
                {
                    message = $"{Name} drank the {inventory.items[i]._name} and nothing happened.";
                    inventory.Remove(inventory.items[i]);
                    break;
                }
            }
            RecentActions.Add(message);
        }
        /// <summary>
        /// Equips armor/shields/weapons to blip
        /// </summary>
        public void Equip()
        {
            string message = "";
            for (int i = 0; i < inventory.items.Count; i++)
            {
                if (inventory.items[i] is Equipment)
                {
                    if (inventory.items[i] is Weapon)
                    {
                        try
                        {
                            if (inventory.items[i]._points > weapon._points)
                            {
                                message = $"{Name} equipped the {inventory.items[i]._name}!";
                                attack -= weapon._points;
                                weapon = new Weapon(inventory.items[i]);
                                attack += weapon._points;
                                inventory.Remove(inventory.items[i]);
                                break;

                            }
                        }
                        catch (NullReferenceException)
                        {
                            message = $"{Name} equipped the {inventory.items[i]._name}!";
                            weapon = new Weapon(inventory.items[i]);
                            attack += weapon._points;
                            inventory.Remove(inventory.items[i]);
                            break;

                        }
                    }
                    else if (inventory.items[i] is Armor)
                    {
                        try
                        {
                            if (inventory.items[i]._points > armor._points)
                            {
                                message = $"{Name} equipped the {inventory.items[i]._name}!";
                                defense -= armor._points;
                                armor = new Armor(inventory.items[i]);
                                defense += armor._points;
                                inventory.Remove(inventory.items[i]);
                                break;

                            }
                        }
                        catch (Exception)
                        {
                            message = $"{Name} equipped the {inventory.items[i]._name}!";
                            armor = new Armor(inventory.items[i]);
                            defense += armor._points;
                            inventory.Remove(inventory.items[i]);
                            break;
                        }
                    }
                    else
                    {
                        try
                        {
                            if (inventory.items[i]._points > shield._points)
                            {
                                message = $"{Name} equipped the {inventory.items[i]._name}!";
                                defense -= shield._points;
                                shield = new Shield(inventory.items[i]);
                                defense += shield._points;
                                inventory.Remove(inventory.items[i]);
                                break;
                            }
                            
                        }
                        catch(NullReferenceException) 
                        {
                            message = $"{Name} equipped the {inventory.items[i]._name}!";
                            shield = new Shield(inventory.items[i]);
                            defense += shield._points;
                            inventory.Remove(inventory.items[i]);
                            break;
                        }
                    }
                }
            }
            RecentActions.Add(message);
        }

    }
}
