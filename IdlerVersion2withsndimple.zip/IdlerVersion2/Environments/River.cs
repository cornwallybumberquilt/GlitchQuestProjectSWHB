﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    internal class River : Environment
    {
        public River(int size) : base(size) { }

        public void HandleCollision() { }
    }
}
