﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Environments
{
    internal class Environment : Square
    {
        public Environment(int size) : base(size) { }

        public void HandleCollision() { }
    }
}
