﻿//Team Mystic: Cecil, Clayton, Ash, Billy, Alex, Logan
namespace IdlerVersion2.Inventory
{
    internal class Potion : Item
    {
        int _potionEffect;
        public Potion(string name) : base(name)
        {
            throw new NotImplementedException();
        }
    }
}
